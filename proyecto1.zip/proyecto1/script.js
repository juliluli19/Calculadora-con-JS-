const pantalla = document.querySelector(".pantalla");//este lee la paguina y de eso mismo hace clases para poder definirlas
const botones = document.querySelectorAll(".boton");

//programar las funcioness

botones.forEach(boton =>//se inicia un evento
{

    boton.addEventListener("click", () =>//cuando de click el boton toma el valor que tiene 
    {
        const botonOn = boton.textContent;//guarda el valor que contiene el boton en botonOn
        //pantalla.textContent = botonOn; guarda el valor que contiene el boton

        if (boton.id == "borrar")//funcion para borrar uno en uno de derecha a izquierda de las patalla
        {
            if (pantalla.textContent.length == 1)//aqui se estabelce que si la pantalla llega a un numero y se le da en borar se pone un 0 en su lugar 
            {
                pantalla.textContent = "0";
            } else
            {
                pantalla.textContent = pantalla.textContent.slice(0, -1);
            } return;
        }

        if (boton.id == "igual")//condicion que ayuda a evaluar los numeros de pantalla y dar un resultado
        {
            try
            {
                pantalla.textContent = eval(pantalla.textContent);
            } catch {
                pantalla.textContent = " Error  ¯\_(ツ)_ /¯";//cahea la pantalla y si no se puede operar bota error
            }
            return;
        }

        // if (pantalla.textContent === "0" || pantalla.textContent === " Error  ¯\_(ツ)_ /¯")//
        // {
        //     pantalla.textContent = botonOn;
        // } else
        // {
        //     pantalla.textContent != botonOn;
        // }

        if (pantalla.textContent === "0" || pantalla.textContent === " Error  ¯\_(ツ)_ /¯")//crea una condicion para cambiar el 0 de la pantalla por el numero que seleccionemos 
        {
            pantalla.textContent = botonOn;
        } else
        {
            pantalla.textContent += botonOn;//guarda el valor que contiene el boton y lo pone en pantalla
        }

        if (boton.id == "limpiar")//condicion para el boton de limpiar la pantalla
        {
            if (pantalla.textContent == "")
            {
                pantalla.textContent = "0";

            }

            return;
        }



    })

})